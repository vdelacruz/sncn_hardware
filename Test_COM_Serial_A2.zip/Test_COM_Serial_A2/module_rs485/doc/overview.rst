Overview
========

This module implements a half-duplex RS485 UART with direction control. Integer baud rates up to 1 Mbps are supported along with one or two stop bits, 7, 8 or 9 data bits, and odd/even/no parity.

The component can sustain 1Mbps in a single 62.5MIPS thread.
