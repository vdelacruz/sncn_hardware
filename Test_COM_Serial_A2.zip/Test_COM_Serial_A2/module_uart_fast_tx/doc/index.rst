XCORE STAND ALONE UART COMPONENTS
=================================

.. toctree::

   summary.rst
   fast.rst



