
Slicekit CAN Bus Simple Demo
****************************

scope:
   Example

description:
   A demonstration of a simple device that can send and receive data
   through the CAN Phy layer.

keywords:
   CAN,Tx,Rx

boards:
   XA-SK-ISBUS

This simple demonstration of xTIMEcomposer Studio functionality that
uses the XA-SK-ISBUS Slice Card together with the xSOFTip module_can
to demonstrate how the module is used to transmit and recieve data
over a CAN bus.
