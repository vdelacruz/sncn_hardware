#!/bin/bash

echo "SOMANET-C22-ComECAT-IfmBLDC-XScope"
